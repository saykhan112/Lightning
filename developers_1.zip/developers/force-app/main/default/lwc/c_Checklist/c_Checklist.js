import { LightningElement, track, wire } from "lwc";
import Header_Text from "@salesforce/label/c.Healder_Label";
import getCheckList from "@salesforce/apex/CC_ChecklistController.getCheckList";
import getCheckListItems from "@salesforce/apex/CC_ChecklistController.getCheckListItems";
import saveChecklistItem from "@salesforce/apex/CC_ChecklistController.saveChecklistItem";
import Checklist_OBJECT from "@salesforce/schema/Checklist__c";
import Name_Field from "@salesforce/schema/Checklist__c.Name";
import End_Date_Field from "@salesforce/schema/Checklist__c.End_Date__c";
import Is_Active_Field from "@salesforce/schema/Checklist__c.Is_Active__c";
import Start_Date_FIELD from "@salesforce/schema/Checklist__c.Start_Date__c";
import Type_FIELD from "@salesforce/schema/Checklist__c.Type__c";
import Status_FIELD from "@salesforce/schema/checklist_Items__c.Status__c";

import updateChecklistUserLookup from "@salesforce/apex/CC_ChecklistController.updateChecklistUserLookup";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { refreshApex } from "@salesforce/apex";
import { NavigationMixin } from "lightning/navigation";
import { getPicklistValues } from "lightning/uiObjectInfoApi";
import { getObjectInfo } from "lightning/uiObjectInfoApi";
const actions = [{ label: "Detail", name: "detail" }];
const checklistItemsActions = [{ label: "Detail", name: "detail" }];

export default class C_Checklist extends NavigationMixin(LightningElement) {
  label = {
    Header_Text
  };
  @track checklist;
  @track checklistItems;
  @track showChecklistItems = false;
  @track exists = false;
  @track showCreateChecklistModal = false;
  checklistObjectname = "Checklist__c";
  checklistItemObjectname = "checklist_Items__c";
  ChecklistFields = [Name_Field, Type_FIELD, Start_Date_FIELD, End_Date_Field];
  ChecklistItemFields = [];
  @track columns = [
    {
      fieldName: "url",
      label: "Name",
      sortable: false,
      type: "url",
      initialWidth: 200,
      typeAttributes: {
        target: "_blank",
        label: {
          fieldName: "Name"
        }
      }
    },
    // {
    //   fieldName: "Name",
    //   label: "Name",
    //   sortable: false,
    //   type: "text",
    //   initialWidth: 200
    // },
    {
      fieldName: "Type__c",
      label: "Type",
      sortable: false,
      type: "text",
      initialWidth: 200
    },
    {
      fieldName: "Start_Date__c",
      label: "Start Date",
      sortable: false,
      type: "DATE",
      initialWidth: 200
    },
    {
      fieldName: "End_Date__c",
      label: "End Date",
      sortable: false,
      type: "DATE",
      initialWidth: 200
    },
    {
      fieldName: "Is_Active__c",
      label: "Is Active",
      sortable: false,
      type: "boolean",
      initialWidth: 100
    },
    {
      fieldName: "User_Name__c",
      label: "User",
      sortable: false,
      type: "text",
      initialWidth: 200
    }
    // {
    //   type: "action",
    //   typeAttributes: { rowActions: checklistItemsActions }
    // }
  ];

  @track checklistItemsColumns = [
    {
      fieldName: "url",
      label: "Name",
      sortable: false,
      type: "url",
      initialWidth: 200,
      typeAttributes: {
        target: "_blank",
        label: {
          fieldName: "Name"
        }
      }
    },
    // {
    //   fieldName: "Name",
    //   label: "Name",
    //   sortable: false,
    //   type: "text",
    //   initialWidth: 200
    // },

    {
      fieldName: "Description__c",
      label: "Description",
      sortable: false,
      type: "text",
      initialWidth: 400
    },

    {
      fieldName: "Status__c",
      label: "Status",
      sortable: false,
      type: "text",
      initialWidth: 200
    },
    
    {
      fieldName: "Checklist_Type__c",
      label: "Checklist Type",
      sortable: false,
      type: "text",
      initialWidth: 200
    },
    {
      fieldName: "Checklist_UserName__c",
      label: "Checklist UserName",
      sortable: false,
      type: "text",
      initialWidth: 200
    }
    
    // {
    //   type: "action",
    //   typeAttributes: { rowActions: actions }
    // }
  ];
  @track chcklistId;
  @track page = 0;
  @track pageLimit = 10;
  @track totalRecords;
  wiredChecklistResult;
  @wire(getCheckList, {})
  wiredChecklist(result) {
    this.wiredChecklistResult = result;
    console.log(result.data);
    if (result.data) {
      //   this.checklist = result.data.sobList;
      let response = Object.assign([], result.data.sobList);
      console.log(response);
      let checklists = [];

      for (let index = 0; index < response.length; index++) {
        let temp = Object.assign({}, response[index]);
        temp.url =
          "https://sknew-developer-edition.ap15.force.com/cs/s/detail/" +
          temp.Id;
        checklists.push(temp);
      }
      this.checklist = checklists;
      if (result.data.sobList.length > 0) {
        this.exists = true;
        this.chcklistId = this.checklist[0].Id;
      } else {
        this.exists = false;
      }
      console.log(this.data);
    } else if (result.error) {
      console.error(result.error);
    }
  }

  wiredChecklistItemResult;
  @wire(getCheckListItems, {
    checklistId: "$chcklistId",
    page: "$page",
    pageLimit: "$pageLimit"
  })
  wiredChecklistItems(result) {
    this.wiredChecklistItemResult = result;
    console.log(result.data);
    if (result.data) {
      //   this.checklistItems = result.data.sobList;
      let response = Object.assign([], result.data.sobList);
      this.totalRecords = result.data.totalCount;
      let items = [];
      for (let index = 0; index < response.length; index++) {
        let temp = Object.assign({}, response[index]);
        temp.url =
          "https://sknew-developer-edition.ap15.force.com/cs/s/detail/" +
          temp.Id;
        items.push(temp);
      }
      this.checklistItems = items;
      if (this.checklistItems.length > 0) {
        this.showChecklistItems = true;
      } else {
        this.showChecklistItems = false;
      }
    } else if (result.error) {
      console.error(result.error);
    }
  }

  get isFirstPage() {
    return this.page == 0;
  }

  get isLastPage() {
    if (this.totalRecords <= (this.page + 1) * this.pageLimit) {
      return true;
    } else {
      return false;
    }
  }

  loadNextPage() {
    this.page++;
  }

  loadPreviousPage() {
    this.page--;
  }

  handleAddChecklistButtonClick(event) {
    this.showCreateChecklistModal = true;
  }

  @track showCreateChecklistItemModal = false;
  handleAddChecklistItemButtonClick(event) {
    this.showCreateChecklistItemModal = true;
    this.checkListItem = {
      Name: "",
      Status__c: "",
      Description__c: "",
      Checklist__c: ""
    };
  }

  closeCreateChecklistItemModal(event) {
    this.showCreateChecklistItemModal = false;
  }

  closeCreateChecklistModal(event) {
    this.showCreateChecklistModal = false;
  }

  handleCreatedChecklist(event) {
    let id = event.detail.id;
    updateChecklistUserLookup({ id: id })
      .then(result => {
        if (result.successfull) {
          this.showSuccessResponse();
          this.showCreateChecklistModal = false;
          return refreshApex(this.wiredChecklistResult);
          // this.resetForm();
        } else {
          this.showErrorResponse(result.response);
        }
      })
      .catch(error => {
        console.error(error);
        this.showErrorResponse("Error occured while populating user lookup");
      });
  }

  showErrorResponse(message) {
    const evt = new ShowToastEvent({
      title: "Failure",
      message: message,
      variant: "error",
      mode: "dismissable"
    });
    this.dispatchEvent(evt);
  }

  showSuccessResponse() {
    const evt = new ShowToastEvent({
      title: "Success",
      message: "Checklist Added Successfully",
      variant: "success",
      mode: "dismissable"
    });
    this.dispatchEvent(evt);
  }

  showSuccessResponseI() {
    const evt = new ShowToastEvent({
      title: "Success",
      message: "Checklist Item Added Successfully",
      variant: "success",
      mode: "dismissable"
    });
    this.dispatchEvent(evt);
  }

  @track checkListItem = {
    Name: "",
    Status__c: "",
    Description__c: "",
    Checklist__c: ""
  };

  @wire(getObjectInfo, {
    objectApiName: Checklist_OBJECT
  })
  objectInfo;

  @track StatusPicklistValues = [];
  @wire(getPicklistValues, {
    recordTypeId: "$objectInfo.data.defaultRecordTypeId",
    fieldApiName: Status_FIELD
  })
  wireStatusPicklistValues({ error, data }) {
    if (data) {
      // console.log(data);
      this.StatusPicklistValues = data.values;
    } else if (error) {
      console.error(error);
    }
  }
  onChangeName(event) {
    this.checkListItem.Name = event.target.value;
  }
  handleStatusDropdownChange(event) {
    this.checkListItem.Status__c = event.target.value;
  }

  onChangeDescription(event) {
    this.checkListItem.Description__c = event.target.value;
  }

  submitChecklistItem(event) {
    this.checkListItem.Checklist__c = this.chcklistId;
    console.log(this.checkListItem);
    saveChecklistItem({
      checklistItem: this.checkListItem
    })
      .then(result => {
        if (result.successfull) {
          this.showSuccessResponseI();
          this.showCreateChecklistItemModal = false;
          return refreshApex(this.wiredChecklistItemResult);
        } else {
          console.log("hree");
          this.showErrorResponse("Error occured while saving checklist item");
        }
      })
      .catch(error => {
        console.error(error);
        this.showErrorResponse("Error occured while saving checklist item");
      });
  }

  handleRowAction(event) {}

  handleItemRowAction(event) {}
}