import { LightningElement } from 'lwc';

export default class C_ChecklistItem extends LightningElement {}